/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: The above reference directives must remain at the top of this file.
// They enable Next.js type definitions and global image types without
// polluting the rest of your project. Do not remove or modify them.